package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    // Register
    @PostMapping("/register")
    public String register(@RequestBody User user) {
        if (userRepository.findByUsername(user.getUsername()) != null) {
            return "USERNAME_EXISTS";
        }
        userRepository.save(user);
        return "REGISTER_SUCCESS";
    }

    // Login
    @PostMapping("/login")
    public String login(@RequestBody User user) {
        User u = userRepository.findByUsernameAndPassword(
                user.getUsername(), user.getPassword());

        if (u != null) {
            return "LOGIN_SUCCESS";
        }
        return "INVALID_CREDENTIALS";
    }
}
